#include <stdio.h>
//#include "add.h"
int main()
{
  printf("hello!\n");
  //printf("%d\n", add(1, 2));
  return 0;
}